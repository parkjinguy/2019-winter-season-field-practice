﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
namespace admin_update
{
    /// <summary>
    /// insertin3.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class insertin3 : Window
    {
        private static string mysql_str = "server=localhost;port=3306;Database=pjg;Uid=root;Pwd=1234;Charset=utf8";
        MySqlConnection conn = new MySqlConnection(mysql_str);
        MySqlCommand cmd1 = null;
        String sql = null;
        MySqlDataReader reader = null;
        insert3 upa;
        public insertin3(insert3 ins3)
        {
            InitializeComponent();
            upa = ins3;

            //MessageBox.Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (ch1.IsChecked == true)
            {
                sql = "insert into topsub(topsubject,uses,stare) values('" + t1.Text + "','on',0)";

            }
            else
            {
                sql = "insert into topsub(topsubject,uses,stare) values('" + t1.Text + "','off',0)";
            }
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }
            else
            {
                conn.Close();
                conn.Open();
            }
            cmd1 = new MySqlCommand(sql, conn);
            cmd1.ExecuteNonQuery();
            MessageBox.Show("추가되었습니다.");
            upa.read();
            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
