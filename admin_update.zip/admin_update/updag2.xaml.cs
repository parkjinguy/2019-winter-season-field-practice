﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Diagnostics;
namespace admin_update
{
    /// <summary>
    /// updag2.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class updag2 : Window
    {
        update2 up = new update2();
        update2 upa;
        private static string mysql_str = "server=localhost;port=3306;Database=pjg;Uid=root;Pwd=1234;Charset=utf8";
        MySqlConnection conn = new MySqlConnection(mysql_str);
        MySqlCommand cmd1 = null;
        String sql = null;
        MySqlDataReader reader = null;
        String indx1 = Application.Current.Properties["idx1"].ToString();
        String indx2 = Application.Current.Properties["idx2"].ToString();
        public updag2()
        {
            InitializeComponent();
            go();
            sql = "select * from subj_list where idx=" + indx1 + " and top_idx=" + indx2;
            cmd1 = new MySqlCommand(sql, conn);
            reader = cmd1.ExecuteReader();
            reader.Read();
            t1.Text = reader[1].ToString();
            t2.Text = reader[3].ToString();
            com1.Text = reader[2].ToString();
            if (reader[5].ToString() == "on")
            {
                che1.IsChecked = true;
            }
            conn.Close();
        }
        public updag2(update2 uap)//부모창 정보 받아서 처음실행
        {
            InitializeComponent();
            go();
            sql = "select * from subj_list where idx=" + indx1 + " and top_idx=" + indx2;
            cmd1 = new MySqlCommand(sql, conn);
            reader = cmd1.ExecuteReader();
            reader.Read();
            t1.Text = reader[1].ToString();
            t2.Text = reader[3].ToString();
            com1.Text = reader[2].ToString();
            if (reader[5].ToString() == "on")
            {
                che1.IsChecked = true;
            }
            conn.Close();
            upa = uap;// 부모창 타입 변수에 부모창 정보 입력
        }
        public void go()
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            go();
            String ch = null;
            if (che1.IsChecked == true)
            {
                ch = "on";
            }
            else
            {
                ch = "off";
            }
            sql = "update subj_list set subject='" + t1.Text + "', kind='" + com1.Text + "', width=" + t2.Text + ", view='" + ch + "' where idx=" + indx1 + " and top_idx=" + indx2;
            cmd1 = new MySqlCommand(sql, conn);
            cmd1.ExecuteNonQuery();
            MessageBox.Show("수정되었습니다.");
            upa.read();//부모창 새로고침
            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Close();

        }
    }
}
