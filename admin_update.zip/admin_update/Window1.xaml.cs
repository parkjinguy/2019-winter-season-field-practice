﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Data;
using System.Configuration;
using MySql.Data.MySqlClient;
using LiveCharts;
using LiveCharts.Wpf;
namespace admin_update
{
    /// <summary>
    /// Window1.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Window1 : Window
    {
        private static string mysql_str =
      "server=localhost;port=3306;Database=pjg;Uid=root;Pwd=1234;Charset=utf8";
        MySqlConnection conn = new MySqlConnection(mysql_str);
        MySqlCommand cmd1 = null;
        MySqlDataReader reader = null;
        String sql1 = null;
        String sql2 = null;
        String tmp1=Application.Current.Properties["idx1"].ToString();
        String tmp2=Application.Current.Properties["idx2"].ToString();
        List<String> sq = new List<string>();
        public Window1()
        {
            InitializeComponent();
            go();
            sql2 = "select * from obj_list where top_idx=" + tmp1 +" and idx=" + tmp2;
            cmd1 = new MySqlCommand(sql2, conn);
            reader = cmd1.ExecuteReader();
            reader.Read();
            PointLabel = chartPoint => string.Format("{0} ({1:P})", chartPoint.Y, chartPoint.Participation);
            for (int i = 0; i < 7; i++)
                {
                    if (reader[i + 12].ToString() == "")
                    {
                        sq.Add("0");
                    }
                    else
                    {
                        sq.Add(reader[i + 12].ToString());
                    }
                }
                DataContext = this;
                pp.Series = new SeriesCollection();
                //Series - Each Slice of the pie. 
                PieSeries pie = new PieSeries();
                pie.Title = "항목1";
                pie.Values = new ChartValues<double> { Convert.ToDouble(sq[0]) };
                pie.DataLabels = true;
                pie.LabelPoint = PointLabel;
                pp.Series.Add(pie);

                PieSeries pie1 = new PieSeries();
                pie1.Title = "항목2";
                pie1.Values = new ChartValues<double> { Convert.ToDouble(sq[1]) };
                pie1.DataLabels = true;
                pie1.LabelPoint = PointLabel;
                pp.Series.Add(pie1);

                PieSeries pie2 = new PieSeries();
                pie2.Title = "항목3";
                pie2.Values = new ChartValues<double> { Convert.ToDouble(sq[2]) };
                pie2.DataLabels = true;
                pie2.LabelPoint = PointLabel;
                pp.Series.Add(pie2);


                PieSeries pie3 = new PieSeries();
                pie3.Title = "항목4";
                pie3.Values = new ChartValues<double> { Convert.ToDouble(sq[3]) };
                pie3.DataLabels = true;
                pie3.LabelPoint = PointLabel;
                pp.Series.Add(pie3);


                PieSeries pie4 = new PieSeries();
                pie4.Title = "항목5";
                pie4.Values = new ChartValues<double> { Convert.ToDouble(sq[4]) };
                pie4.DataLabels = true;
                pie4.LabelPoint = PointLabel;
                pp.Series.Add(pie4);


                PieSeries pie5 = new PieSeries();
                pie5.Title = "항목6";
                pie5.Values = new ChartValues<double> { Convert.ToDouble(sq[5]) };
                pie5.DataLabels = true;
                pie5.LabelPoint = PointLabel;
                pp.Series.Add(pie5);


                PieSeries pie6 = new PieSeries();
                pie6.Title = "항목7";
                pie6.Values = new ChartValues<double> { Convert.ToDouble(sq[6]) };
                pie6.DataLabels = true;
                pie6.LabelPoint = PointLabel;
                pp.Series.Add(pie6);
        }
        public Func<ChartPoint, string> PointLabel { get; set; }
        public void go()
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }
            else
            {
                conn.Close();
                conn.Open();
            }
        }
    }
}
