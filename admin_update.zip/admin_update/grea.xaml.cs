﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data;
namespace admin_update
{
    /// <summary>
    /// grea.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class grea : Page
    {
        String top;
        String idx;
        private static string mysql_str =
   "server=localhost;port=3306;Database=pjg;Uid=root;Pwd=1234;Charset=utf8";
        MySqlConnection conn = new MySqlConnection(mysql_str);
        MySqlCommand cmd1 = null;
        MySqlDataReader reader = null;
        String sql1 = null;
        public grea()
        {
            InitializeComponent();
            top=Application.Current.Properties["idx1"].ToString();
            idx=Application.Current.Properties["idx2"].ToString();
            go();
            sql1 = "select * from obj_list where top_idx="+top+" and idx="+idx;
            cmd1 = new MySqlCommand(sql1, conn);
            reader = cmd1.ExecuteReader();
            int i = 50;
            Color color = Color.FromRgb(148, 170, 59);
            SolidColorBrush brus = new SolidColorBrush(color) ;
            reader.Read();
            int ca= Convert.ToInt32(reader.GetString("num"));
            String[] colm = { "ch1_cn", "ch2_cn", "ch3_cn", "ch4_cn", "ch5_cn", "ch6_cn", "ch7_cn", };
            for (int c=0;c<ca;c++)
            {
                int con=Convert.ToInt32(reader.GetString(colm[c]));
                if (con != 0)
                {
                    Line lin = new Line();
                    lin.X1 = 0;
                    lin.X2 = con;
                    lin.Y1 = i;
                    lin.Y2 = i;
                    i += 20;
                    lin.Stroke = brus;
                    lin.StrokeThickness = 2;
                    lim.Children.Add(lin);
                    int[] tb = { 4, 173, 200, 397 };
                    Thickness ty = new Thickness();
                    Label la = new Label();
                    ty.Left = tb[0];
                    ty.Top = tb[1];
                    ty.Right = tb[2];
                    ty.Bottom = tb[3];
                    la.Margin = ty;
                    la.Content = "항목" + i;
                    la.Width = 40;
                    la.Height = 25;
                    la.Name = "la" + i;
                    mainGrid.Children.Add(la);
                }
            }
        }
        public void go()
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }
            else
            {
                conn.Close();
                conn.Open();
            }
        }




        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/select.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/select2.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/update.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/update2.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/insert.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_5(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/insert2.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_6(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/insert3.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_7(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/drop.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_8(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/delete.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_9(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/delete2.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_11(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/result.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_10(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/result2.xaml", UriKind.Relative));
        }
    }
}
