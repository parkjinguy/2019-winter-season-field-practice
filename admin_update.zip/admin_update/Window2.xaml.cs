﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Drawing;
using MySql.Data.MySqlClient;
using System.Data;

namespace admin_update
{
    /// <summary>
    /// Window2.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Window2 : Window
    {
        private static string mysql_str =
     "server=localhost;port=3306;Database=pjg;Uid=root;Pwd=1234;Charset=utf8";
        MySqlConnection conn = new MySqlConnection(mysql_str);
        MySqlCommand cmd1 = null;
        MySqlDataReader reader = null;
        String sql1 = null;
        String sql2 = null;
        String sql3 = null;
        public Window2()
        {
            InitializeComponent();
                
            go();
            sql1 = "select * from obj_list where top_idx=3";
            cmd1 = new MySqlCommand(sql1, conn);
            reader = cmd1.ExecuteReader();
            Thickness ty = new Thickness();
            int[] tb = { 10, 136, 330, 215 };
            String[] colm = { "항목1 : ", "항목2 : ", "항목3 : ", "항목4 : ", "항목5 : ", "항목6 : ", "항목7 : " };
            int i = 11;
            int y = 150;
            while (reader.Read())
            {
                Line l = new Line();
                l.X1 = 100; l.Y1 = y;
                String tt;
                try
                {
                    tt = reader[i].ToString();
                    if (tt == "")
                    {
                        tt = "0";
                    }
                }catch(Exception aa)
                {
                    tt = "0";
                }
                int num;
                Int32.TryParse(tt, out num);
                l.X2 =num+100; l.Y2 = y;
                l.Stroke = System.Windows.Media.Brushes.Black;
                l.StrokeThickness = 10;
                //l.StrokeDashArray = DoubleCollection.Parse("4, 3");
                Plotter.Children.Add(l);
                TextBlock la = new TextBlock();
                ty.Left = tb[0];
                ty.Top = tb[1];
                ty.Right = tb[2];
                ty.Bottom = tb[3];
                la.Margin = ty;
                la.Text = colm[i - 11]+tt;
                la.Width = 50;
                la.Height = 25;
                Plotter.Children.Add(la);

                i++;y += 20;
                tb[1] +=25;
            }
        }
        public void go()
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }
            else
            {
                conn.Close();
                conn.Open();
            }
        }

    }
}
