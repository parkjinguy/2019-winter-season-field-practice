﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace admin_update
{
    /// <summary>
    /// login.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class login : Page
    {
        private static string mysql_str =
       "server=localhost;port=3306;Database=pjg;Uid=root;Pwd=1234;Charset=utf8";
        //"Server=l.bsks.ac.kr;Port=3306;Database=p201887078;Uid=p201887078;Pwd=pp201887078;";
        MySqlConnection conn = new MySqlConnection(mysql_str);
        MySqlCommand cmd1;
        MySqlDataReader reader;
        public login()
        {
            InitializeComponent();
        }

        private void PW_KeyDown(object sender, KeyEventArgs e)
        {
            var id = ID.Text;
            var pw = PW.Password;
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }
            if (e.Key == Key.Return)
            {
                String sql1 = "select * from admin where id='" + id + "' and pw='" + pw + "';";
                cmd1 = new MySqlCommand(sql1, conn);

                reader = cmd1.ExecuteReader();
                if (reader.Read())
                {

                    MessageBox.Show("로그인 성공");
                    NavigationService.Navigate(new Uri("/main.xaml", UriKind.Relative));

                }
                else
                {
                    //Window ii = new failure();
                    //ii.Show();
                    MessageBox.Show("로그인 실패");
                }
                reader.Close();
            }
        }
    }
}
