﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
namespace admin_update
{
    /// <summary>
    /// insertin.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class insertin : Window
    {
        String idx = Application.Current.Properties["idx1"].ToString();
        insert upa;
        List<TextBox> li = new List<TextBox>();
        private static string mysql_str = "server=localhost;port=3306;Database=pjg;Uid=root;Pwd=1234;Charset=utf8";
        MySqlConnection conn = new MySqlConnection(mysql_str);
        MySqlCommand cmd1 = null;
        MySqlCommand cmd2 = null;
        String sql = null;
        String sql2 = null;
        MySqlDataReader reader = null;
        public insertin(insert it)
        {
            InitializeComponent();
            com2.Items.Add("선택");
            for (int i = 1; i < 8; i++)
            {
                com2.Items.Add(i);
            }
            upa = it;
            com1.SelectedIndex = com1.Items.Count - 3;
            com2.SelectedIndex = com2.Items.Count - 8;
        }
        public void cat(int ac)
        {
            try
            {
                this.mainGrid.Children.RemoveRange(0, 14);
            }
            catch (Exception e)
            {
            }
            int[] tb = { 10, 146, 330, 215 };
            int[] mb = { 100, 130, 0, 200 };
            Thickness ty = new Thickness();

            Thickness my = new Thickness();

            for (int i = 1; i <= ac; i++)
            {

                Label la = new Label();
                ty.Left = tb[0];
                ty.Top = tb[1];
                ty.Right = tb[2];
                ty.Bottom = tb[3];
                la.Margin = ty;
                la.Content = "항목" + i;
                la.Width = 40;
                la.Height = 25;
                la.Name = "la" + i;
                mainGrid.Children.Add(la);
                li.Add(new TextBox());
                // TextBox text1 = new TextBox();
                // NameScope.SetNameScope(text1, new NameScope());
                my.Left = mb[0];
                my.Top = mb[1];
                my.Right = mb[2];
                my.Bottom = mb[3];
                li[i - 1].Margin = my;
                li[i - 1].Name = "text" + i;
                li[i - 1].Width = 300;
                li[i - 1].Height = 25;
                li[i - 1].FontSize = 15;
                this.mainGrid.Children.Add(li[i - 1]);
                tb[1] += 29;
                tb[3] -= 29;
                mb[1] += 28;
                mb[3] -= 28;
                //tex[i - 1] = text1;
            }
        }
        public void go()
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }
            else
            {
                conn.Close();
                conn.Open();
            }
        }

        private void com2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                int co = Convert.ToInt32(com2.SelectedItem.ToString());
                cat(co);
            }
            catch (Exception ee)
            {

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (com1.Text != "선택해주세요" && com2.Text != "선택해주세요")
            {
                sql2 = "select count(idx)+1 as con from obj_list where top_idx=" +idx;
                go();
                cmd2 = new MySqlCommand(sql2, conn);
                try
                {
                    reader = cmd2.ExecuteReader();
                    reader.Read();
                    sql = "insert into obj_list(idx,subject,kind,num,ch1,ch2,ch3,ch4,ch5,ch6,ch7,view,top_idx) values(" + reader.GetString("con") + ",'" + t1.Text + "','" + com1.Text + "','" + com2.Text + "',";
                }
                catch (Exception aa)
                {
                    sql = "insert into obj_list(idx,subject,kind,num,ch1,ch2,ch3,ch4,ch5,ch6,ch7,view,top_idx) values(1,'" + t1.Text + "','" + com1.Text + "','" + com2.Text + "',";

                }
                for (int i = 0; i < Convert.ToInt32(com2.Text); i++)
                {
                    sql += "'" + li[i].Text + "',";
                }
                for (int i = 0; i < 7 - Convert.ToInt32(com2.Text); i++)
                {
                    sql += "'',";
                }
                if (che1.IsChecked == true)
                {
                    sql += "'on',";
                }
                else
                {
                    sql += "'off',";
                }
                sql += idx + ")";
                go();
                cmd1 = new MySqlCommand(sql, conn);
                //MessageBox.Show(sql);
                cmd1.ExecuteNonQuery();
                MessageBox.Show("추가 되었습니다.");
                upa.read();
                Close();
            }
            else
            {
                MessageBox.Show("버튼종류나 항목갯수가 선택되지 않았습니다.");
            }
        }
    }
}
