﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms.DataVisualization.Charting;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LiveCharts;
using LiveCharts.Wpf;

namespace admin_update
{
    /// <summary>
    /// test.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class test : Page
    {
        Dictionary<int, double> value;
        public test()
        {
            InitializeComponent();
            chart.LegendLocation = LiveCharts.LegendLocation.Top;

            //세로 눈금 값 설정
            chart.AxisY.Add(new LiveCharts.Wpf.Axis { MinValue = 0, MaxValue = 1000 });

            //가로 눈금 값 설정
            chart.AxisX.Add(new LiveCharts.Wpf.Axis { Labels = new string[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" } });



            //모든 항목 지우기
            chart.Series.Clear();

            //항목 추가
            chart.Series.Add(new LiveCharts.Wpf.LineSeries()
            {
                Title = "Sample1",
                Stroke = new SolidColorBrush(Colors.Green),
                Values = new LiveCharts.ChartValues<double>(new List<double> { 700 })
            }
            );
            chart.Series.Add(new LiveCharts.Wpf.LineSeries()
            {
                Title = "Sample2",
                Stroke = new SolidColorBrush(Colors.Red),
                Values = new LiveCharts.ChartValues<double>(new List<double> { 70})
            }
            );

        }

    }
}
