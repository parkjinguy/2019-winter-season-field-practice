﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
namespace admin_update
{
    /// <summary>
    /// updag.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class updag : Window
    {
        update upw = new update();
        update upc;
        List<TextBox> li = new List<TextBox>();
        List<ComboBox> lc = new List<ComboBox>();
        List<CheckBox> lk = new List<CheckBox>();
        List<String> chke = new List<string>();
        List<String> numm = new List<String>();
        int count2 = 0;
        private static string mysql_str = "server=localhost;port=3306;Database=pjg;Uid=root;Pwd=1234;Charset=utf8";
        MySqlConnection conn = new MySqlConnection(mysql_str);
        MySqlCommand cmd1 = null;
        String sql = null;
        MySqlDataReader reader = null;
        String indx1 = Application.Current.Properties["idx1"].ToString();
        String indx2 = Application.Current.Properties["idx2"].ToString();
        int num = 0;
        String test1 = null;
        String test2 = null;
        String test3 = null;
        String test4 = null;
        String test5 = null;
        String test6 = null;
        String test7 = null;
        public updag(update upa)
        {
            InitializeComponent();
            go();
            for (int i = 1; i < 8; i++)
            {
                com2.Items.Add(i);
            }
            sql = "select * from obj_list where idx=" + indx1 + " and top_idx=" + indx2;
            cmd1 = new MySqlCommand(sql, conn);
            reader = cmd1.ExecuteReader();
            if (reader.Read())
            {
                t1.Text = reader[1].ToString();
                com1.Text = reader[2].ToString();
                if (reader[4].ToString() == "on")
                {
                    che1.IsChecked = true;
                }
                upc = upa;// 부모창 타입 변수에 부모창 정보 입력
                int a = Convert.ToInt32(reader[3].ToString());
                count = a;
                test1 = reader[5].ToString();
                test2 = reader[6].ToString();
                test3 = reader[7].ToString();
                test4 = reader[8].ToString();
                test5 = reader[9].ToString();
                test6 = reader[10].ToString();
                test7 = reader[11].ToString();
                for (int i = 19; i < 26; i++)
                {
                    chke.Add(reader[i].ToString());
                    numm.Add(reader[i + 7].ToString());
                }
                cat(a);
                com2.SelectedIndex = a-1;
            }
        }
        int count = 0;
        String tmp;
        public void com(int a)
        {
            go();
            sql = "select count(ch1) from obj_list where top_idx=" + indx2;
            cmd1 = new MySqlCommand(sql, conn);
            reader = cmd1.ExecuteReader();
            reader.Read();
            int c = Convert.ToInt32(reader[0].ToString());
            lc[a].Items.Clear();
            for (int d = 0; d < c+1; d++)
            {
                lc[a].Items.Add(d);
            }
            count2 = c;
        }
        public void cat(int ac)
        {
            String[] ch = { test1, test2, test3, test4, test5, test6, test7 };
            try
            {
                this.mainGrid.Children.RemoveRange(0, 21);
            }
            catch (Exception e)
            {
            }
            int[] tb = { 10, 146, 330, 215 };
            int[] mb = { 50, 130, 40, 200 };
            int[] cb = { 300, 130, 0, 200 };
            int[] ck = { 500, 130, 0, 200 };
            Thickness ty = new Thickness();
            Thickness cy = new Thickness();
            Thickness ky = new Thickness();
            Thickness my = new Thickness();

            for (int i = 1; i <= ac; i++)
            {

                Label la = new Label();
                ty.Left = tb[0];
                ty.Top = tb[1];
                ty.Right = tb[2];
                ty.Bottom = tb[3];
                la.Margin = ty;
                la.Content = "항목" + i;
                la.Width = 40;
                la.Height = 25;
                la.Name = "la" + i;
                mainGrid.Children.Add(la);
                li.Add(new TextBox());
                // TextBox text1 = new TextBox();
                // NameScope.SetNameScope(text1, new NameScope());
                my.Left = mb[0];
                my.Top = mb[1];
                my.Right = mb[2];
                my.Bottom = mb[3];
                li[i - 1].Margin = my;
                li[i - 1].Name = "text" + i;
                li[i - 1].Text = ch[i - 1];
                li[i - 1].Width = 200;
                li[i - 1].Height = 25;
                li[i - 1].FontSize = 15;
                try
                {
                    this.mainGrid.Children.Add(li[i - 1]);
                }catch(Exception ee)
                {
                }
                

                ky.Left = ck[0];
                ky.Top = ck[1];
                ky.Right = ck[2];
                ky.Bottom = ck[3];
                lk.Add(new CheckBox());
                lk[i - 1].Margin = ky;
                lk[i - 1].Name = "ck" + i;
                lk[i - 1].Content = "비활성화";
                lk[i - 1].Height = 20;
                if (chke[i - 1].ToString() == "off")
                {

                    lk[i - 1].IsChecked = true;
                }
                else
                {
                    lk[i - 1].IsChecked = false;
                }
                try
                {
                    this.mainGrid.Children.Add(lk[i - 1]);
                }catch(Exception ee)
                {

                }

                cy.Left = cb[0];
                cy.Top = cb[1];
                cy.Right = cb[2];
                cy.Bottom = cb[3];
                lc.Add(new ComboBox());
                lc[i - 1].Margin = cy;
                lc[i - 1].Name = "co" + i;
                lc[i - 1].Width = 60;
                lc[i - 1].Height = 20;
                com(i - 1);
                int tmp=0;
                try
                {
                    tmp = Convert.ToInt32(numm[i - 1]);
                }catch(Exception ee)
                {
                }
                
                if (tmp == 0)
                {
                    tmp = count2;
                }
                lc[i - 1].SelectedIndex = lc[i -1].Items.Count - tmp-1;
                try
                {
                    this.mainGrid.Children.Add(lc[i - 1]);
                }catch(Exception ee)
                {

                }
                tb[1] += 29;
                tb[3] -= 29;
                mb[1] += 28;
                mb[3] -= 28;
                cb[1] += 29;
                cb[3] -= 29;
                ck[1] += 29;
                ck[3] -= 29;
                //tex[i - 1] = text1;
            }
        }
        public void go()
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }
            else
            {
                conn.Close();
                conn.Open();
            }
        }
        private void com2_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            int co = Convert.ToInt32(com2.SelectedItem.ToString());
            cat(co);
            //com(co);
        }

        public void Button_Click(object sender, RoutedEventArgs e)
        {
            //String document = this.mainGrid.FindName("text1").ToString();
            String aa = null;

            int check = 0;
            for (int i = 0; i < Convert.ToInt32(com2.Text); i++)
            {
                int tmp = i + 1;
                if (li[i].Text == "")
                {
                    MessageBox.Show("내용이 빠졌습니다.");
                    check = 1;
                    break;
                }
                aa += "ch" + tmp + "='" + li[i].Text + "'";

                if (i != Convert.ToInt32(com2.Text) - 1)
                {
                    aa += ",";
                }
            }

            sql = "update obj_list set subject='" + t1.Text + "', kind='" + com1.Text + "', num='" + com2.Text + "',";
            for (int i = 1; i < Convert.ToInt32(com2.Text) + 1; i++)
            {
                if (lc[i - 1].Text != "")
                {
                    sql += " inCh" + i + "=" + lc[i - 1].Text + ",";
                }
                else
                {
                    sql += "inCh" + i + "=0,";
                }

                if (lk[i - 1].IsChecked == true)
                {
                    sql += "inNum" + i + "='off',";
                }
                else
                {
                    sql += "inNum" + i + "='on',";
                }
            }

            if (che1.IsChecked == true)
            {
                sql += "view='on', ";
            }
            sql += aa + "";
            sql += " where idx=" + indx1 + " and top_idx=" + indx2;
            go();
            cmd1 = new MySqlCommand(sql, conn);
            if (check == 0)
            {
                cmd1.ExecuteNonQuery();
                MessageBox.Show("수정이 되었습니다.");
            }
            upc.read();//부모창 새로고침
            Close();
        }
    }
}
