﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data;
namespace admin_update
{
    /// <summary>
    /// insert2.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class insert2 : Page
    {
        private static string mysql_str =
   "server=localhost;port=3306;Database=pjg;Uid=root;Pwd=1234;Charset=utf8";
        MySqlConnection conn = new MySqlConnection(mysql_str);
        MySqlCommand cmd1 = null;
        MySqlDataReader reader = null;
        String sql1 = null;
        String sql2 = null;
        DataRowView d;
        String tmp = null;
        public insert2()
        {
            InitializeComponent();
            go();
            DataRowView d = grid1.CurrentCell.Item as System.Data.DataRowView;
            DataTable table = new DataTable();
            table.Columns.Add("설문 번호", typeof(String));
            table.Columns.Add("설문 제목", typeof(String));
            table.Columns.Add("사용 여부", typeof(String));
            table.Columns.Add("응시횟수", typeof(String));
            sql1 = "select * from topsub";
            cmd1 = new MySqlCommand(sql1, conn);
            reader = cmd1.ExecuteReader();
            while (reader.Read())
            {
                table.Rows.Add(new string[] { reader[0].ToString(), reader[1].ToString(), reader[2].ToString(), reader[3].ToString() });
            }
            grid1.ItemsSource = table.DefaultView;
        }

        private void grid1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                DataRowView c = grid1.CurrentCell.Item as System.Data.DataRowView;
                string a = c.Row[0].ToString();
                t1.Text = "";
                t1.Text = a;
            }
            catch (Exception b)
            {
                t1.Text = "";
            }
            sql2 = "select * from subj_list where top_idx=" + t1.Text;
            tmp = t1.Text;
            DataRowView d = grid2.CurrentCell.Item as System.Data.DataRowView;
            DataTable table = new DataTable();
            go();
            cmd1 = new MySqlCommand(sql2, conn);
            reader = cmd1.ExecuteReader();
            table.Columns.Add("주관식 질문번호", typeof(String));
            table.Columns.Add("제목", typeof(String));
            table.Columns.Add("입력박스 종류", typeof(String));
            table.Columns.Add("입력박스 넓이", typeof(String));
            table.Columns.Add("사용여부", typeof(String));
            while (reader.Read())
            {
                table.Rows.Add(new string[] { reader[0].ToString(), reader[1].ToString(), reader[2].ToString(), reader[3].ToString(), reader[5].ToString()});
            }
            grid2.ItemsSource = table.DefaultView;
        }
        public void go()
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }
            else
            {
                conn.Close();
                conn.Open();
            }
        }
        public void read()
        {
            try
            {
                DataRowView c = grid1.CurrentCell.Item as System.Data.DataRowView;
                string a = c.Row[0].ToString();
                t1.Text = "";
                t1.Text = a;
            }
            catch (Exception b)
            {
                t1.Text = "";
            }
            sql2 = "select * from subj_list where top_idx=" + t1.Text;
            tmp = t1.Text;
            DataRowView d = grid2.CurrentCell.Item as System.Data.DataRowView;
            DataTable table = new DataTable();
            go();
            cmd1 = new MySqlCommand(sql2, conn);
            reader = cmd1.ExecuteReader();
            table.Columns.Add("주관식 질문번호", typeof(String));
            table.Columns.Add("제목", typeof(String));
            table.Columns.Add("입력박스 종류", typeof(String));
            table.Columns.Add("입력박스 넓이", typeof(String));
            table.Columns.Add("사용여부", typeof(String));
            while (reader.Read())
            {
                table.Rows.Add(new string[] { reader[0].ToString(), reader[1].ToString(), reader[2].ToString(), reader[3].ToString(), reader[5].ToString() });
            }
            grid2.ItemsSource = table.DefaultView;
        }
        private void grid1_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                d = grid1.CurrentCell.Item as System.Data.DataRowView;
                Application.Current.Properties["idx1"] = d.Row[0].ToString();
                insertin2 it = new insertin2(this);
                it.Show();
            }
            catch (Exception ee)
            {
            }
        }
        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/select.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/select2.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/update.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/update2.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/insert.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_5(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/insert2.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_6(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/insert3.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_7(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/drop.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_8(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/delete.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_9(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/delete2.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_11(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/result.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_10(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/result2.xaml", UriKind.Relative));
        }
    }
}
