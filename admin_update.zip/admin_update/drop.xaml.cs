﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data;
namespace admin_update
{
    /// <summary>
    /// drop.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class drop : Page
    {
        private static string mysql_str =
  "server=localhost;port=3306;Database=pjg;Uid=root;Pwd=1234;Charset=utf8";
        MySqlConnection conn = new MySqlConnection(mysql_str);
        MySqlCommand cmd1 = null;
        MySqlCommand cmd2 = null;
        MySqlCommand cmd3 = null;
        MySqlCommand cmd4 = null;
        MySqlCommand cmd5 = null;
        MySqlCommand cmd6 = null;
        MySqlDataReader reader = null;
        String sql1 = null;
        String sql2 = null;
        DataRowView d;
        String tmp = null;
        public drop()
        {
            InitializeComponent();
            view();
        }
        public void view()
        {
            go();
            DataRowView d = grid1.CurrentCell.Item as System.Data.DataRowView;
            DataTable table = new DataTable();
            table.Columns.Add("설문 번호", typeof(String));
            table.Columns.Add("설문 제목", typeof(String));
            table.Columns.Add("사용 여부", typeof(String));
            table.Columns.Add("응시횟수", typeof(String));
            sql1 = "select * from topsub";
            cmd1 = new MySqlCommand(sql1, conn);
            reader = cmd1.ExecuteReader();
            while (reader.Read())
            {
                table.Rows.Add(new string[] { reader[0].ToString(), reader[1].ToString(), reader[2].ToString(), reader[3].ToString() });
            }
            grid1.ItemsSource = table.DefaultView;
        }
        public void go()
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }
            else
            {
                conn.Close();
                conn.Open();
            }
        }
        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/select.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/select2.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/update.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/update2.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/insert.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_5(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/insert2.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_6(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/insert3.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_7(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/drop.xaml", UriKind.Relative));
        }

        private void grid1_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (MessageBox.Show("정말 삭제합니까?", "", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                try
                {
                    DataRowView c = grid1.CurrentCell.Item as System.Data.DataRowView;
                    string a = c.Row[0].ToString();
                    t1.Text = "";
                    t1.Text = a;
                }
                catch (Exception b)
                {
                    t1.Text = "";
                }
                go();
                sql2= "select * from obj_use where top_idx=" + t1.Text;
                cmd6 = new MySqlCommand(sql2, conn);
                reader = cmd6.ExecuteReader();
                if (reader.Read())
                {
                    MessageBox.Show("설문이 진행중 입니다.");
                }
                else
                {
                    if (t1.Text != "")
                    {
                        String sql2 = "delete from topsub where top_idx=" + t1.Text;
                        String sql3 = "delete from obj_list where top_idx=" + t1.Text;
                        String sql4 = "delete from subj_list where top_idx=" + t1.Text;
                        String sql5 = "delete from subj_answer where top_idx=" + t1.Text;
                        go();
                        cmd2 = new MySqlCommand(sql5, conn);
                        cmd2.ExecuteNonQuery();
                        go();
                        cmd3 = new MySqlCommand(sql4, conn);
                        cmd3.ExecuteNonQuery();
                        go();
                        cmd4 = new MySqlCommand(sql3, conn);
                        cmd4.ExecuteNonQuery();
                        go();
                        cmd5 = new MySqlCommand(sql2, conn);
                        cmd5.ExecuteNonQuery();
                        MessageBox.Show("삭제 되었습니다.");
                        view();
                    }
                    else
                    {
                        MessageBox.Show("취소 되었습니다.");
                    }
                }
                
            }
        }

        private void MenuItem_Click_8(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/delete.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_9(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/delete2.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_11(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/result.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_10(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/result2.xaml", UriKind.Relative));
        }
    }
}
