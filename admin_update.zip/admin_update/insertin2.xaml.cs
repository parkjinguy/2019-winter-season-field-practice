﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Diagnostics;
namespace admin_update
{
    /// <summary>
    /// insertin2.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class insertin2 : Window
    {
        insert2 upa;
        private static string mysql_str = "server=localhost;port=3306;Database=pjg;Uid=root;Pwd=1234;Charset=utf8";
        MySqlConnection conn = new MySqlConnection(mysql_str);
        MySqlCommand cmd1 = null;
        MySqlCommand cmd2 = null;
        String sql = null;
        String sql2 = null;
        MySqlDataReader reader = null;
        String idx = Application.Current.Properties["idx1"].ToString();

        public insertin2(insert2 uap)//부모창 정보 받아서 처음실행
        {
            InitializeComponent();
            com1.SelectedIndex = com1.Items.Count - 3;
            upa = uap;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
        private void go()
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }
            else
            {
                conn.Close();
                conn.Open();
            }
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            go();
            String name = t1.Text;
            String width = t2.Text;
            String com = com1.Text;
            String che = null;
            String row = null;
            if (che1.IsChecked == true)
            {
                che = "on";
            }
            else
            {
                che = "off";
            }
            if (com1.Text == "text")
            {
                row = "";
            }
            else
            {
                row = "5";
            }
            sql2 = "select count(idx)+1 as con from subj_list where top_idx=" +idx;
            go();
            cmd2 = new MySqlCommand(sql2, conn);
            reader = cmd2.ExecuteReader();
            reader.Read();
            sql = "insert into subj_list(idx,subject,kind,width,m_height,view,top_idx) values("+reader.GetString("con")+",'" + name + "','" + com + "'," + width + ",'" + row + "','" + che + "'," + idx + ")";
            go();
            cmd1 = new MySqlCommand(sql, conn);
            cmd1.ExecuteNonQuery();
            MessageBox.Show("추가되었습니다.");
            upa.read();//부모창 새로고침
            Close();
        }
    }
}
