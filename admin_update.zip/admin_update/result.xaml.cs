﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data;
namespace admin_update
{
    /// <summary>
    /// result.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class result : Page
    {
        private static string mysql_str =
     "server=localhost;port=3306;Database=pjg;Uid=root;Pwd=1234;Charset=utf8";
        MySqlConnection conn = new MySqlConnection(mysql_str);
        MySqlCommand cmd1 = null;
        MySqlDataReader reader = null;
        String sql1 = null;
        String sql2 = null;
        String sql3 = null;
        String top = null;
        public result()
        {
            InitializeComponent();
            go();
            DataRowView d = grid1.CurrentCell.Item as System.Data.DataRowView;
            DataTable table = new DataTable();
            table.Columns.Add("설문 번호", typeof(String));
            table.Columns.Add("설문 제목", typeof(String));
            table.Columns.Add("사용 여부", typeof(String));
            table.Columns.Add("응시횟수", typeof(String));
            sql1 = "select * from topsub";
            cmd1 = new MySqlCommand(sql1, conn);
            reader = cmd1.ExecuteReader();
            while (reader.Read())
            {
                table.Rows.Add(new string[] { reader[0].ToString(), reader[1].ToString(), reader[2].ToString(), reader[3].ToString() });
            }
            grid1.ItemsSource = table.DefaultView;
        }
        public void go()
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }
            else
            {
                conn.Close();
                conn.Open();
            }
        }
        private void grid1_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                DataRowView c = grid1.CurrentCell.Item as System.Data.DataRowView;
                string a = c.Row[0].ToString();
                t1.Text = "";
                t1.Text = a;
                top = a;
            }
            catch (Exception b)
            {
                t1.Text = "";
            }
            sql2 = "select * from obj_list where top_idx=" + t1.Text;
            DataRowView d = grid2.CurrentCell.Item as System.Data.DataRowView;
            DataTable table = new DataTable();
            go();
            cmd1 = new MySqlCommand(sql2, conn);
            reader = cmd1.ExecuteReader();
            table.Columns.Add("객관식 질문번호", typeof(String));
            table.Columns.Add("제목", typeof(String));
            table.Columns.Add("버튼종류", typeof(String));
            table.Columns.Add("항목갯수", typeof(String));
            table.Columns.Add("사용여부", typeof(String));
            table.Columns.Add("항목1", typeof(String));
            table.Columns.Add("항목1 횟수", typeof(String));
            table.Columns.Add("항목2", typeof(String));
            table.Columns.Add("항목2 횟수", typeof(String));
            table.Columns.Add("항목3", typeof(String));
            table.Columns.Add("항목3 횟수", typeof(String));
            table.Columns.Add("항목4", typeof(String));
            table.Columns.Add("항목4 횟수", typeof(String));
            table.Columns.Add("항목5", typeof(String));
            table.Columns.Add("항목5 횟수", typeof(String));
            table.Columns.Add("항목6", typeof(String));
            table.Columns.Add("항목6 횟수", typeof(String));
            table.Columns.Add("항목7", typeof(String));
            table.Columns.Add("항목7 횟수", typeof(String));

            while (reader.Read())
            {
                table.Rows.Add(new string[] { reader["idx"].ToString(),reader["subject"].ToString(),reader["kind"].ToString(),reader["num"].ToString(),reader["view"].ToString(),reader["ch1"].ToString()
                    ,reader["ch1_cn"].ToString(),
                    reader["ch2"].ToString(),reader["ch2_cn"].ToString(),reader["ch3"].ToString(),reader["ch3_cn"].ToString(),reader["ch4"].ToString(),reader["ch4_cn"].ToString(),
                    reader["ch5"].ToString(),reader["ch5_cn"].ToString(),
                    reader["ch6"].ToString(),reader["ch6_cn"].ToString(),reader["ch7"].ToString(),reader["ch7_cn"].ToString()});
            }
            grid2.ItemsSource = table.DefaultView;
        }
        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/select.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/select2.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/update.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/update2.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/insert.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_5(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/insert2.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_6(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/insert3.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_7(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/drop.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_8(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/delete.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_9(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/delete2.xaml", UriKind.Relative));
        }

        private void MenuItem_Click_11(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/result.xaml", UriKind.Relative));
        }

        private void grid2_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                DataRowView c = grid2.CurrentCell.Item as System.Data.DataRowView;
                string a = c.Row[0].ToString();
                t1.Text = "";
                t1.Text = a;
            }
            catch (Exception b)
            {
                t1.Text = "";
            }
            Application.Current.Properties["idx1"] = top;
            Application.Current.Properties["idx2"] = t1.Text;
            Window1 wi = new Window1();
            wi.Show();
        }

        private void MenuItem_Click_10(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/result2.xaml", UriKind.Relative));
        }
    }
}
